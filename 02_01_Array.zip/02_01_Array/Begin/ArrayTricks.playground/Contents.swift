import Foundation

struct Pizza{
    var name:String
    var size:Double
    var veg:Bool
}
var pizzas = [Pizza(name: "Cheese", size: 10.0,veg:true)]
pizzas += [Pizza(name: "Huli Chicken", size: 16.0,veg:false)]
pizzas += [Pizza(name: "Big Island", size:18.0,veg:false)]
pizzas += [Pizza(name: "Margherita", size:10.0,veg:true)]
pizzas += [Pizza(name: "Quattro Formaggi", size:10.0,veg:true)]
pizzas += [Pizza(name: "Pepperoni", size:12.0,veg:false)]
pizzas += [Pizza(name: "Long Board", size:14.0,veg:true)]
pizzas += [Pizza(name: "Hawaiian", size:12.0,veg:false)]

//find

//filter

//aggregate -- reduce max min, sum and average

