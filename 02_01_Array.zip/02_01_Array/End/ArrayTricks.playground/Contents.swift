import Foundation

struct Pizza{
    var name:String
    var size:Double
    var veg:Bool
}
var pizzas = [Pizza(name: "Cheese", size: 10.0,veg:true)]
pizzas += [Pizza(name: "Huli Chicken", size: 16.0,veg:false)]
pizzas += [Pizza(name: "Big Island", size:18.0,veg:false)]
pizzas += [Pizza(name: "Margherita", size:10.0,veg:true)]
pizzas += [Pizza(name: "Quattro Formaggi", size:10.0,veg:true)]
pizzas += [Pizza(name: "Pepperoni", size:12.0,veg:false)]
pizzas += [Pizza(name: "Long Board", size:14.0,veg:true)]
pizzas += [Pizza(name: "Hawaiian", size:12.0,veg:false)]

print (pizzas.map{$0.size})
//find
print(pizzas.first{$0.size > 12.0} ?? 0)


//filter
print(pizzas.filter{$0.veg}.map{$0.name})
print(pizzas.filter{$0.size > 12.0}.map{$0.name})

//aggregate -- reduce max min, sum and average
print (pizzas.map{$0.size}.reduce(0.0,+)/Double(pizzas.count))
